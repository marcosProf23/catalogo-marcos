import './App.css'
import Cartao from './cartao';
import foto1 from './imagens/marcos.jpg';
import foto2 from './imagens/ana.jpg';
import foto3 from './imagens/carlos.jpg';


const pessoas = [
  {
    id: 1,
    nome: "Marcos",
    idade: 5,
    email: 'marcos@gmail.com',
    telefone: '7599999999'
  }
  
];

function App() {
 return (
    <div className='container'>
      <Cartao foto={foto1} nome="Marcos" idade="25" email = 'marcos@gmail.com' telefone='7599999999' />
      <Cartao foto={foto2} nome="Ana" idade="30" email = 'ana@gmail.com' telefone='7599999999'/>
      <Cartao foto={foto3} nome="Carlos" idade="67"email = 'carlos@gmail.com' telefone='7599999999' />   
      
    </div>
  );
}

export default App
