import logo from "./imagens/senai_logo.png"; 
function Rodape(){
    return(
        <header>
            <div className="rodape">
                <center>
                
                <img src={logo}  alt="senai"/>
                <h5>Todos os direitos reservados. 2026</h5>

                </center>
                

            </div>
        </header>
    );
}
export default Rodape;