import { useState } from "react";
import "./App.css";
import Topo from "./Topo";
import Rodape from "./Rodape";
import Cartao from "./cartao"
import CartaoProfessor from "./cartaoProfessor";
import CartaoLaboratorio from "./cartaoLaboratorio";
import alunos from "./dados_alunos";
import professores from "./dados_professores";
import laboratorios from "./dados_laboratorios";

function App() {

  const [secao, setSecao] = useState("alunos");

  return (
    <>
      <Topo />

      <div className="menu">
        <button onClick={() => setSecao("alunos")}>Alunos</button>
        <button onClick={() => setSecao("professores")}>Professores</button>
        <button onClick={() => setSecao("laboratorios")}>Laboratórios</button>
      </div>

      <div className="container">

        {secao === "alunos" &&
          alunos.map((aluno, index) => (
            <Cartao
              key={index}
              foto={aluno.foto}
              nome={aluno.nome}
              email={aluno.email}
              telefone={aluno.telefone}
            />
          ))
        }

        {secao === "professores" &&
          professores.map((prof, index) => (
            <CartaoProfessor
              key={index}
              foto={prof.foto}
              nome={prof.nome}
              area={prof.area}
              cargo={prof.cargo}
              email={prof.email}
            />
          ))
        }

        {secao === "laboratorios" &&
          laboratorios.map((lab, index) => (
            <CartaoLaboratorio
              key={index}
              foto={lab.foto}
              nome={lab.nome}
              localizacao={lab.localizacao}
              computadores={lab.computadores}
            />
          ))
        }

      </div>

      <Rodape />
    </>
  );
}

export default App;